---
layout: page
title: "Contact"
show_meta: false
subheadline: "Wufoo-powered contact forms"
description: "Get in touch with me? Use the contact form."
permalink: "/contact/"
---
If you need a fabulous contact form for your website, I suggest you use [Wufoo][1]. You can use three forms for free, you get no spam and if you get more than 100 entries you have to pay.

<div class="panel">
<iframe width="100%" height="650" frameborder="0" scrolling="no" src="https://phlowmedia.wufoo.com/embed/z7x3k1/"></iframe>
</div>



 [1]: http://www.wufoo.com/
