function [pred,prob] = classfTmtl_LR_te(model,Xsrc_test,Xtars_test)
% Test the model of logistic regression under the framework of
%	transfer-sample-based multitask learning (TMTL), see classfTmtl_LR
%
% model:	The model learned in classfTmtl_LR_tr
% Xsrc_test:	The test samples in the source domain.
% Xtars_test:	The test samples in the target domains, If the number of
%	target domains is nTargetDomains, then Xtars_test should be a cell
%	array with nTargetDomains elements, Xtars_test{i} are the test samples
%	in the i'th domain.
% output: pred and prob are predicted labels and probabilities. They both
%	are structs with two fields: src and tars.
%	rv.tars is a cell array like Xtars_test.

prob = [];
pred = [];
if exist('Xsrc_test','var') && ~isempty(Xsrc_test)
	Xsrc_test = [ones(size(Xsrc_test,1),1),Xsrc_test];
	prob.src = sigmoid(Xsrc_test*model.betasSrc);
	if size(model.betasSrc,2) == 1
		pred.src = prob.src >= .5;
		pred.src = 2-pred.src;
		prob.src = [prob.src,1-prob.src];
	else
		[maxProb,pred.src] = max(prob.src,[],2);
	end
end

if exist('Xtars_test','var') && ~isempty(Xtars_test)
	nTargetDomains = size(model.betasTars,3);
	for iTd = 1:nTargetDomains
		Xtars_test1 = [ones(size(Xtars_test{iTd},1),1),Xtars_test{iTd}];
		prob.Sl{iTd} = sigmoid(Xtars_test1*model.betasTars(:,:,iTd));
	
		if size(model.betasTars,2) == 1
			pred.Sl{iTd} = prob.Sl{iTd} >= .5;
			pred.Sl{iTd} = 2-pred.Sl{iTd};
			prob.Sl{iTd} = [prob.Sl{iTd},1-prob.Sl{iTd}];
		else
			[maxProb,pred.Sl{iTd}] = max(prob.Sl{iTd},[],2);
		end
	end
end

end

function g = sigmoid(z)
g = 1.0 ./ (1.0 + exp(-z));
end