function rv = regressTmtl_ridge_te(model,Xsrc_test,Xtars_test)
% Test the model of ridge regression under the framework of
%	transfer-sample-based multitask learning (TMTL), see regressTmtl_ridge_tr
%
% model:	The model learned in regressTmtl_ridge_tr
% Xsrc_test:	The test samples in the source domain.
% Xtars_test:	The test samples in the target domains, If the number of
%	target domains is nTargetDomains, then Xtars_test should be a cell
%	array with nTargetDomains elements, Xtars_test{i} are the test samples
%	in the i'th domain.
% rv: The predicted values. It is a struct with two fields: src and tars.
%	rv.tars is a cell array like Xtars_test.

if ~isempty(Xsrc_test)
	Xsrc_test = [ones(size(Xsrc_test,1),1),Xsrc_test];
	rv.src = Xsrc_test*model.betaSrc;
end

if exist('Xtars_test','var') && ~isempty(Xtars_test)
	nTargetDomains = size(model.betaTars,2);
	for iTd = 1:nTargetDomains
		XSl_te1 = [ones(size(Xtars_test{iTd},1),1),Xtars_test{iTd}];
		rv.tars{iTd} = XSl_te1*model.betaTars(:,iTd);
	end
end

end
