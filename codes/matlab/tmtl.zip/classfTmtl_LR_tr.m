function [model] = classfTmtl_LR_tr(Xsrc,Ysrc,Tsrc,Ttar,param)
% Logistic regression under the framework of parallel or serial
%	transfer-sample-based multitask learning (TMTL).

% src: source domain, like the master device or before drift
% tar: target domain, like the slave device or after drift.
% Xsrc and Ysrc: the training samples and their outputs. each row is a sample
% T: transfer samples (unlabeled). If there are nTargetDomains target
%	domains, then Tsrc and Ttar are cell arrays with nTargetDomains
%	elements, Tsrc{t} and Ttar{t} are corresponding transfer sample groups,
%	Each row of Tsrc and Ttar are corresponding transfer samples from both domains.
%
% It is better to normalize X and T before this function, using methods
%	such as standard normal variate (SNV)
% param: Struct of hyper-parameters, please see the first cell of this
%	program ("default parameters") for details. You can set parameter p to
%	x by setting param.p = x. For parameters that are not set, default
%	values will be used.
%	If any param is not provided, default values will be used, see the
% first cell of the code "default parameters"

% output: model, stores the learned projection vectors of src and tar domains
%	and some other statistics. See the codes below.

%	ref: Ke Yan, David Zhang, and Yong Xu, "Learning Classification and
% Regression Models for Data with Drift based on Transfer Samples", under
% review.
% Copyright 2016 YAN Ke, Tsinghua Univ. http://yanke23.com , xjed09@gmail.com

%% default parameters
l1 = 2^-3; % the weight of the transfer sample term
l2 = 2^2; % the weight of the model similarity term
mu = 0.1; % the weight of the standardization-error-based model	improvement (SEMI) term
isSerial = true; % if false, parallel TMTL, all models are similar to the
% avg model; if true, serial TMTL, each model is similar to the one of
% the previous domain, i.e. model t is similar to t-1. See the ref.
useSemi = true; % whether use weighted penalty in SEMI. If false, use constant penalty
useSim2 = true; % if true, use the relaxed model similarity term; if false,
% use the traditional model similarity term
defParam

%% sort data
[nSmp,nFt] = size(Xsrc);
Xsrc = [ones(nSmp,1),Xsrc]; % add constant column
nClass = max(Ysrc);
nTargetDomains = length(Ttar);
nDomains = nTargetDomains+1;

%% compute feature weights
ftWts = zeros(nTargetDomains,nFt);
for iTd = 1:nTargetDomains
	if useSemi
		ftWts(iTd,:) = sum((Tsrc{iTd}-Ttar{iTd}).^2,1);
	else
		ftWts(iTd,:) = ones(1,nFt);
	end
	Tsrc{iTd} = [ones(size(Tsrc{iTd},1),1),Tsrc{iTd}];
	Ttar{iTd} = [ones(size(Ttar{iTd},1),1),Ttar{iTd}];
end
ftWts = [mean(ftWts,1);ftWts];
ftWts = ftWts/mean(ftWts(:))*abs(mu);

%% optimization
initTheta = zeros((nFt+1)*nDomains,1);
options = optimset('GradObj','on','MaxIter',500,'Display','off');
fmin = @fmincg;

if nClass == 2 % only compute one theta, will be faster
	f = @(t)lrCostFunction(t,Xsrc,(Ysrc==1),Tsrc,Ttar,ftWts,l1,l2,isSerial,useSim2); % the 3rd para should be 0 or 1
	[betas,fs,iterNum] = fmin(f,initTheta,options);
else
	betas = zeros((nFt+1)*nDomains,nClass); % one vs all
	for p = 1:nClass
		f = @(t)lrCostFunction(t,Xsrc,(Ysrc==p),Tsrc,Ttar,ftWts,l1,l2,isSerial,useSim2); % the 3rd para should be 0 or 1
		[betas(:,p),fs,iterNum] = fmin(f,initTheta,options);
	end
end
% 	toc;
model.betasSrc = betas(1:nFt+1,:);
model.betasTars = permute(reshape(betas(nFt+2:end,:),nFt+1,...
	nTargetDomains,nClass-(nClass==2)),[1 3 2]);
model.costEstm = costEstm(Xsrc,Ysrc,model.betasSrc);
for iTd = 1:nTargetDomains
	model.coefDiff(iTd,:) = mean((model.betasSrc(2:end,:)-model.betasTars(2:end,:,iTd)).^2,1);
	model.tranDiff(iTd,:) = mean((Tsrc{iTd}*model.betasSrc-Ttar{iTd}*model.betasTars(:,:,iTd)).^2,1);
end

end

function cost = costEstm(X,Y,betas)

hyp = sigmoid(X*betas); % hypothesis
subNum = size(betas,2);
cost = zeros(1,subNum);
for cls = 1:subNum
	Y1 = Y==cls;
	cost(cls) = -mean(Y1.*log(hyp(:,cls))+(1-Y1).*log(1-hyp(:,cls)));
end
cost = mean(cost);

end

function [J, grad] = lrCostFunction(beta2,Xsrc,Ysrc,Tsrc,Ttar,ftWts,l1,l2,...
	isSerial,useSim2)

nFt = size(Xsrc,2);
nSmpSrc = length(Ysrc);
nTargetDomains = length(Ttar);

betaSrc = beta2(1:nFt,:);
betaTars = reshape(beta2(1+nFt:end,:),nFt,nTargetDomains);
hyp = sigmoid(Xsrc*betaSrc); % hypothesis
cost = -sum(Ysrc.*log(hyp)+(1-Ysrc).*log(1-hyp)) / nSmpSrc;
lossG = [Xsrc'*(hyp-Ysrc)/nSmpSrc; zeros(nFt*nTargetDomains,1)];

transDiff0 = cell(nTargetDomains,1);
for iTd = 1:nTargetDomains
	transDiff0{iTd} = Tsrc{iTd}*betaSrc-Ttar{iTd}*betaTars(:,iTd);
end
transDiff = cell2mat(transDiff0);
reg1 = sum(transDiff.^2) /2/length(transDiff);
reg1G = [cell2mat(reshape(Tsrc,[],1))'*transDiff,zeros(nFt,nTargetDomains)];
for iTd = 1:nTargetDomains
	reg1G(:,iTd+1) = -Ttar{iTd}'*transDiff0{iTd};
end
reg1G = reg1G(:)*l1/length(transDiff);
		
if ~isSerial % parallel TMTL
	if useSim2
		XPdiff = Xsrc*(betaSrc*ones(1,nTargetDomains)-betaTars);
		reg2 = sum(sum(XPdiff.^2))/2/nTargetDomains/nSmpSrc;
		reg2G = [sum(Xsrc'*XPdiff,2),zeros(nFt,nTargetDomains)];
		for iTd = 1:nTargetDomains
			reg2G(:,iTd+1) = -Xsrc'*XPdiff(:,iTd);
		end
	else
		betaDiff = betaSrc*ones(1,nTargetDomains)-betaTars;
		betaDiff(1,:) = 0;
		reg2 = sum(sum(betaDiff.^2))/2/nTargetDomains;
		reg2G = [sum(betaDiff,2),zeros(nFt,nTargetDomains)];
		for iTd = 1:nTargetDomains
			reg2G(:,iTd+1) = -betaDiff(:,iTd);
		end
	end
else % serial TMTL
	if useSim2
		XPdiff = Xsrc*([betaSrc,betaTars(:,1:nTargetDomains-1)]-betaTars);
		reg2 = sum(sum(XPdiff.^2))/2/nTargetDomains/nSmpSrc;
		reg2G = Xsrc'*([XPdiff,zeros(nSmpSrc,1)]-[zeros(nSmpSrc,1),XPdiff]);
	else
		betaDiff = [betaSrc,betaTars(:,1:nTargetDomains-1)]-betaTars;
		betaDiff(1,:) = 0;
		reg2 = sum(sum(betaDiff.^2))/2/nTargetDomains;
		reg2G = [betaDiff,zeros(nFt,1)]-[zeros(nFt,1),betaDiff];
	end
end
reg2G = reg2G(:)*l2/nTargetDomains/nSmpSrc;

thetaRC = [betaSrc,betaTars]; thetaRC(1,:) = 0; % remove constant
ftWts2 = [zeros(nTargetDomains+1,1),ftWts]';
ftWts2 = ftWts2(:);
penalTerm = sum(thetaRC(:).^2 .* ftWts2)/2;
penalG = thetaRC(:).*ftWts2;

J =  cost + reg1*l1 + reg2*l2 + penalTerm;
grad = lossG + reg1G + reg2G + penalG;

end

function g = sigmoid(z)
g = 1.0 ./ (1.0 + exp(-z));
end
