function [model] = regressTmtl_ridge_tr(Xsrc,Ysrc,Tsrc,Ttar,param)
% Ridge regression under the framework of parallel or serial
%	transfer-sample-based multitask learning (TMTL).

% src: source domain, like the master device or before drift
% tar: target domain, like the slave device or after drift.
% Xsrc and Ysrc: the training samples and their outputs. each row is a sample
% T: transfer samples (unlabeled). If there are nTargetDomains target 
%	domains, then Tsrc and Ttar are cell arrays with nTargetDomains
%	elements, Tsrc{t} and Ttar{t} are corresponding transfer sample groups,
%	Each row of Tsrc and Ttar are corresponding transfer samples from both domains.
%
% It is better to normalize X and T before this function, using methods
%	such as standard normal variate (SNV)
% param: Struct of hyper-parameters, please see the first cell of this
%	program ("default parameters") for details. You can set parameter p to
%	x by setting param.p = x. For parameters that are not set, default
%	values will be used.
%	If any param is not provided, default values will be used, see the
% first cell of the code "default parameters"

% output: model, stores the learned projection vectors of src and tar domains
%	and some other statistics. See the codes below.

%	ref: Ke Yan, David Zhang, and Yong Xu, "Learning Classification and 
% Regression Models for Data with Drift based on Transfer Samples", under
% review.
% Copyright 2016 YAN Ke, Tsinghua Univ. http://yanke23.com , xjed09@gmail.com

%% default parameters
l1 = 2^-3; % the weight of the transfer sample term
l2 = 2^2; % the weight of the model similarity term
mu = 0.1; % the weight of the standardization-error-based model	improvement (SEMI) term
isSerial = true; % if false, parallel TMTL, all models are similar to the 
	% avg model; if true, serial TMTL, each model is similar to the one of
	% the previous domain, i.e. model t is similar to t-1. See the ref.
useSemi = true; % whether use weighted penalty in SEMI. If false, use constant penalty
useSim2 = true; % if true, use the relaxed model similarity term; if false, 
	% use the traditional model similarity term
defParam

%% sort data
[nSmp,nFt] = size(Xsrc);
nFt1 = nFt+1; % with constant term
nTargetDomains = length(Ttar);
Xsrc = [ones(nSmp,1),Xsrc]; % add constant column

%% compute feature weights
ftWts = zeros(nTargetDomains,nFt);
for iTd = 1:nTargetDomains
	if useSemi
		ftWts(iTd,:) = sum((Tsrc{iTd}-Ttar{iTd}).^2,1);
	else
		ftWts(iTd,:) = ones(1,nFt);
	end
	Tsrc{iTd} = [ones(size(Tsrc{iTd},1),1),Tsrc{iTd}];
	Ttar{iTd} = [ones(size(Ttar{iTd},1),1),Ttar{iTd}];
end
ftWts = [mean(ftWts,1);ftWts];
ftWts = ftWts/mean(ftWts(:))*abs(mu);

%% close-form solution of beta
A0 = zeros(nFt1*(nTargetDomains+1));
L = Xsrc'*Xsrc/nSmp;
A0(1:nFt1,1:nFt1) = L;

A1 = zeros(nFt1*(nTargetDomains+1));
for t = 1:nTargetDomains
	Nt = size(Tsrc{t},1);
	A1(1:nFt1,1:nFt1) = A1(1:nFt1,1:nFt1)+Tsrc{t}'*Tsrc{t}/Nt;
	A1(1:nFt1,t*nFt1+1:(t+1)*nFt1) = -Tsrc{t}'*Ttar{t}/Nt;
	A1(t*nFt1+1:(t+1)*nFt1,1:nFt1) = -Ttar{t}'*Tsrc{t}/Nt;
	A1(t*nFt1+1:(t+1)*nFt1,t*nFt1+1:(t+1)*nFt1) = Ttar{t}'*Ttar{t}/Nt;
end

if ~isSerial % parallel TMTL
	if useSim2
		A2 = -repmat(L,nTargetDomains+1,nTargetDomains+1)/(nTargetDomains+1);
		for t = 0:nTargetDomains
			A2(t*nFt1+1:(t+1)*nFt1,t*nFt1+1:(t+1)*nFt1) = -A2(t*nFt1+1:(t+1)*nFt1,t*nFt1+1:(t+1)*nFt1)*nTargetDomains;
		end
	else
		e10 = eye(nFt1); e10(1) = 0;
		A2 = zeros(nFt1*(nTargetDomains+1));
		A2(1:nFt1,1:nFt1) = e10*nTargetDomains;
		for t = 1:nTargetDomains
			A2(1:nFt1,t*nFt1+1:(t+1)*nFt1) = -e10;
			A2(t*nFt1+1:(t+1)*nFt1,1:nFt1) = -e10;
			A2(t*nFt1+1:(t+1)*nFt1,t*nFt1+1:(t+1)*nFt1) = e10;
		end
	end
else % serial TMTL
	if useSim2
		A2 = zeros(nFt1*(nTargetDomains+1));
		A2(1:nFt1,1:nFt1) = L; A2(end-nFt:end,end-nFt:end) = L;
		for t = 1:nTargetDomains-1
			A2(t*nFt1+1:(t+1)*nFt1,t*nFt1+1:(t+1)*nFt1) = L*2;
		end
		for t = 1:nTargetDomains
			A2((t-1)*nFt1+1:t*nFt1,t*nFt1+1:(t+1)*nFt1) = -L;
			A2(t*nFt1+1:(t+1)*nFt1,(t-1)*nFt1+1:t*nFt1) = -L;
		end
	else
		e10 = eye(nFt1); e10(1) = 0;
		A2 = zeros(nFt1*(nTargetDomains+1));
		A2(1:nFt1,1:nFt1) = e10; A2(end-nFt:end,end-nFt:end) = e10;
		for t = 1:nTargetDomains-1
			A2(t*nFt1+1:(t+1)*nFt1,t*nFt1+1:(t+1)*nFt1) = e10*2;
		end
		for t = 1:nTargetDomains
			A2((t-1)*nFt1+1:t*nFt1,t*nFt1+1:(t+1)*nFt1) = -e10;
			A2(t*nFt1+1:(t+1)*nFt1,(t-1)*nFt1+1:t*nFt1) = -e10;
		end
	end
end

ftWts = [zeros(nTargetDomains+1,1),ftWts]';
A3 = diag(ftWts(:));

b = [Xsrc'*Ysrc/nSmp;zeros(nFt1*nTargetDomains,1)];
betas = (A0 + l1*A1/nTargetDomains + l2*A2/nTargetDomains + A3)\b;

%% save the models
model.betaSrc = betas(1:nFt1,:);
model.betaTars = reshape(betas(nFt1+1:end,:),nFt1,nTargetDomains);

% some statistics
model.costEstm = sqrt(mean((Xsrc*model.betaSrc-Ysrc).^2));
for iTd = 1:nTargetDomains
	model.coefDiff(iTd) = mean((model.betaSrc(2:end)-model.betaTars(2:end,iTd)).^2,1);
	model.tranDiff(iTd) = sqrt(mean((Tsrc{iTd}*model.betaSrc-Ttar{iTd}*model.betaTars(:,iTd)).^2));
end

end