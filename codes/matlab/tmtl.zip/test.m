clear
nTargetDomains = 2;

Xsrc = rand(100,50);
Ysrc = (rand(100,1)>1)+1;
Xsrc_test = rand(200,50);

for t = 1:nTargetDomains
	Tsrc{t} = rand(10,50);
	Ttars{t} = rand(10,50);
	Xtar_tests{t} = rand(300,50);
end
param = struct('l1',.1,'l2',1,'mu',.001,'isParallel',true);

%% classfication
model = classfTmtl_LR_tr(Xsrc,Ysrc,Tsrc,Ttars,param);
[pred,prob] = classfTmtl_LR_te(model,Xsrc_test,Xtar_tests);

%% regress
Ysrc = rand(100,1);
model = regressTmtl_ridge_tr(Xsrc,Ysrc,Tsrc,Ttars,param);
rv = regressTmtl_ridge_te(model,Xsrc_test,Xtar_tests);
